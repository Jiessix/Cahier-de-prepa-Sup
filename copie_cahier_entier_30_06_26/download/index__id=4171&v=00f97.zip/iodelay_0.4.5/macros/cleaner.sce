mode(-1);
// ====================================================================
// Copyright (C) INRIA -  Serge Steer
// 
// This file must be used under the terms of the CeCILL.
// This source file is licensed as described in the file COPYING, which
// you should have received as part of this distribution.  The terms
// are also available at    
// http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt
// ====================================================================
curdir=pwd()
chdir(get_absolute_file_path('cleaner.sce'))
tokeep=['black.sci'
	'bode.sci'
	'calfrqrd.sci'
        'freqd.sci'
	'%f_e.sci'
	'iodelay.sci'
	'nyquist.sci'
	'%r_a_rd.sci'
	'%r_c_rd.sci'
	'%rd_a_rd.sci'
	'%rd_a_r.sci'
	'%rd_a_s.sci'
	'%rd_c_rd.sci'
	'%rd_c_r.sci'
	'%rd_c_s.sci'
	'%rd_e.sci'
	'%rd_f_rd.sci'
	'%rd_f_r.sci'
	'%rd_f_s.sci'
	'%rd_i_rd.sci'
	'%rd_i_r.sci'
	'%rd_i_s.sci'
	'%rd_m_rd.sci'
	'%rd_m_r.sci'
	'%rd_m_s.sci'
	'%rd_p.sci'
	'%rd_s_rd.sci'
	'%rd_s_r.sci'
	'%rd_s_s.sci'
        '%rd_size.sci'
	'%rd_string.sci'
	'%rd_t.sci'
	'%rd_x_rd.sci'
	'%rd_x_r.sci'
	'%rd_x_s.sci'
	'repfreqrd.sci'
	'%r_f_rd.sci'
	'%r_i_rd.sci'
	'%r_m_rd.sci'
	'%r_s_rd.sci'
	'%r_x_rd.sci'
	'%s_c_rd.sci'
	'%s_f_rd.sci'
	'%s_i_rd.sci'
	'%s_m_rd.sci'
	'splitdelay.sci'
	'%s_x_rd.sci'
	'buildmacros.sce'
	'cleaner.sce'];
files=listfiles('*')';
for k=tokeep',files(files==k)=[];end
for f=files,mdelete(f),end
chdir(curdir)
clear files f mdelete listfiles curdir tokeep
