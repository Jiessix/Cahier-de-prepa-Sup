//
// Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
// Copyright (C) 2013 David Violeau
//
// This file must be used under the terms of the CeCILL.
// This source file is licensed as described in the file COPYING, which
// you should have received as part of this distribution.  The terms
// are also available at
// http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt
//
//

function [x,y,typ]=READ_CSV_E(job,arg1,arg2)
    x=[];y=[];typ=[];
    select job
    case 'plot' then
        // deprecated
    case 'getinputs' then
        // deprecater
    case 'getoutputs' then
        // deprecated
    case 'getorigin' then
        // deprecated
    case 'set' then
      x=arg1;
      graphics=arg1.graphics;
      exprs=graphics.exprs
      model=arg1.model;
      while %t do
       [ok, path, delimiter, nb_columns,nb_ligns_ignored, exprs] = scicos_getvalue('Paramètres du bloc READ_CSV', ..
        [gettext("Chemin du fichier csv, eg:  E:\my path\file.txt"); gettext("Délimiteur de colonne (, ou ; ou t (pour tabulation))"); gettext("Nombre de colonnes (la première est obligatoirement le temps discrétisé)"); gettext("Nombre de lignes initiales ignorées")], ..
        list("str",-1,"str",-1,"vec",1,"vec",1), exprs);
        if ~ok then break,end
        mess=[];
        if delimiter ~= "t" & delimiter ~= "," & delimiter ~= ";" then
            mess=[mess ;"Le délimiteur doit être une virgule (,) ou un point virgule (;) ou une tabulation (t)"]
            ok = %f
        end
        if nb_columns<2 then
            mess=[mess ;"Le nombre de colonnes doit être plus grand que 1"]
            ok = %f
        end
         if nb_ligns_ignored<0 then
            mess=[mess ;"Le nombre de lignes ignorées est positif"]
            ok = %f
        end     
          
            if ok then
                out = ones(nb_columns-1,1);
                [model,graphics,ok]=set_io(model,graphics,list(),list([out out],out),ones(0,1),[]);
                
                diagram=scicos_diagram();

                clk=SampleCLK('define')
                clk.graphics.peout=3
                clk.graphics.exprs = ["0.1" ; "0"]
                clk.model.rpar = [0.1 ; 0]
                
                diagram.objs(1)=clk
                readcsv=READ_CSV("define")
                readcsv.graphics.exprs=exprs
                readcsv.graphics.pein=3
                [readcsv.model,readcsv.graphics,ok]=set_io(readcsv.model,readcsv.graphics,list(),list([out out],out),ones(1,1),[]);
                readcsv.model.rpar=[nb_columns-1, ascii(delimiter),nb_ligns_ignored];
                readcsv.model.ipar=[ascii(path)]
                diagram.objs(2)=readcsv
                diagram.objs(3)=scicos_link(xx=[0 ; 0],yy=[0 ; 0], ct=[5, -1], from=[1, 1], to=[2, 1])
                
                for i=1:(nb_columns-1)
                    diagram.objs(2*i-1+3)=OUT_f('define')
                    diagram.objs(2*i-1+3).graphics.exprs=string(i)
                    diagram.objs(2*i-1+3).graphics.pin=2*i+3
                    diagram.objs(2*i-1+3).model.ipar=i
                    diagram.objs(2*i+3)=scicos_link(xx=[0 ; 0],yy=[0 ; 0], ct=[1,1], from=[2, i], to=[2*i-1+3, 1])
                end
                diagram.objs(2).graphics.pout=[5:2:2*nb_columns-1+3]

                model.rpar=diagram;
                graphics.exprs = exprs;
                x.model=model;
                x.graphics = graphics;
                break
            else
                message(mess);
            end



        end

    case 'define' then
        exprs=string(["./test.txt";",";"2";"0"])

        diagram=scicos_diagram();
        diagram.objs(1)=SampleCLK('define')
         diagram.objs(1).graphics.peout=4
         diagram.objs(1).graphics.exprs = ["0.1" ; "0"]
         diagram.objs(1).model.rpar = [0.1 ; 0]        
        diagram.objs(2)=READ_CSV("define")
        diagram.objs(2).graphics.pein=4
        diagram.objs(2).graphics.pout=5
        diagram.objs(3)=OUT_f('define')
        diagram.objs(3).graphics.pin=5
      diagram.objs(4)=scicos_link(xx=[0 ; 0],yy=[0 ; 0], ct=[5, -1], from=[1, 1], to=[2, 1])
      diagram.objs(5)=scicos_link(xx=[0 ; 0],yy=[0 ; 0], ct=[1, 1], from=[2, 1], to=[3, 1])

        model = scicos_model();
        model.sim='csuper'
        model.out=1
        model.out2=1
        model.outtyp=1
        model.blocktype='h'
        model.dep_ut=[%f %f]
        model.rpar=diagram
        x = standard_define([4 2], model, "", [])
        x.gui='READ_CSV_E'
        x.graphics.style=["blockWithLabel;verticalLabelPosition=center;displayedLabel=Read CSV"]
        x.graphics.exprs=exprs
    end
endfunction

