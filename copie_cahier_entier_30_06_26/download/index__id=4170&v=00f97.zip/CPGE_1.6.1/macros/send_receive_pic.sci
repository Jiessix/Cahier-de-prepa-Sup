function y1=receive()
    global connected port_TCL isreceiv y1_prec inc t_prec
    if (isreceiv == 1) then
        if (connected==1) then
           [q,flags]=serialstatus(port_TCL)
           while(q<8)
             [q,flags]=serialstatus(port_TCL)
           end
           values=readserial(port_TCL);
           toto=ascii(values)';
           y1(1)=toto(1)*256+toto(2);//position
           y1(2)=toto(3)*256+toto(4);//delta_position
           y1(3)=toto(7)*256+toto(8);//tension
           y1(4)=toto(5)*256+toto(6);//deltaT == 1 top = 0.1ms
           y1=double(int16(y1));
           y1(1)=y1(1)*0.042                        //passage des top en mm
           y1(2)=y1(2)/(toto(5)*256+toto(6))*10000*0.042; //multiplication par 10000 pour passer en top/s
                                                          //multiplication par 0.042 pour passer en mm/s
           y1(3)=y1(3)*12/2044;
           if(t_prec == -1) then 
               y1(4)=0;
           else
               y1(4)=t_prec+(toto(5)*256+toto(6))/10000;  //on prend le temps global et on ajoute le nouveau temps
           end
           t_prec=y1(4);
           //disp(toto(5)*256+toto(6))
           //disp ('receiv')
           inc = inc + 1;
           //disp (inc)
        else
            //disp('Non connecté : receive '+string(y1_test))   
            //y1 = y1_test;
            //inc = inc + 1
            //disp (inc)
            
        end
        isreceiv = 0
    end
endfunction

function y1=send(u1)
    global connected port_TCL isreceiv y1_test
    //disp(u1)
    if (isreceiv == 0) then
        if (connected==1) then
                u1=u1*2044/12; //repassé en inc e non en volts
                values= "P" + ascii((int(evstr(u1)/256))) + ascii(modulo(evstr(u1),256))
                //disp('on envoie : '+values)
                writeserial(port_TCL,values);
             //   disp ('send')
        else
            //disp('Non connecté : send '+string(u1))
            //disp(u1)
        end
        y1=u1
        y1_test = u1
        isreceiv = 1
    end
endfunction
function end_of_simul()
    global inc
    disp(inc)
endfunction

function put_zero()
    if (connected == 1) then
        u1=0;
        values= "P" + ascii((int(evstr(u1)/256))) + ascii(modulo(evstr(u1),256))
        writeserial(port_TCL,values);
        [q,flags]=serialstatus(port_TCL)
        while(q<8)
          [q,flags]=serialstatus(port_TCL)
        end
        values=readserial(port_TCL);

    end
endfunction

function init_serial_com()
    global connected port_TCL isreceiv y1_test inc t_prec
    t_prec =-1;
    if (connected == 1) then
        //Envoie d'une demande de démarrage de travail
        values=readserial(port_TCL);
        nbpoint = 1000;
        writeserial(port_TCL,"T"+ascii((int(evstr(nbpoint)/256))) + ascii(modulo(evstr(nbpoint),256)));
        //Attente de la reception de la trame de DEBUT
        values="";
        while (length(strindex(values,"BEG;")) == 0 )   
            sleep(10);
            values=values+readserial(port_TCL);
            //disp(values)
        end
        disp('Initialisation terminée')
    else
        //messagebox('Mode non connecté')
    end
    isreceiv = 0;
    y1_test = 0;
    //disp('inc '+string(inc));
    inc = 0;
endfunction