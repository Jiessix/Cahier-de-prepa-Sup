// ============================================================================
// Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
// Copyright (C) 2013 - Scilab Enterprises - Bruno JOFRET
//
//  This file is distributed under the same license as the Scilab package.
// ============================================================================
//
// <-- ENGLISH IMPOSED -->
//
// <-- Short Description -->
// GRANDEUR_PHYSIQUE

loadXcosLibs();

// Check where CLR block is defined
[a, b] = libraryinfo(whereis("GRANDEUR_PHYSIQUE"));
assert_checkequal(grep(b, "CPGE"), 1);

funcprot(0);
needcompile = 0;
alreadyran = %f;
%scicos_context = struct();

[status, message] = xcosValidateBlockSet("GRANDEUR_PHYSIQUE");
if status == %f
    disp(message);
end
assert_checktrue(status);

disp(GRANDEUR_PHYSIQUE("define"));
