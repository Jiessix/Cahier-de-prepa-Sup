// ============================================================================
// Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
// Copyright (C) 2013 - Scilab Enterprises - Bruno JOFRET
//
//  This file is distributed under the same license as the Scilab package.
// ============================================================================
//
// <-- ENGLISH IMPOSED -->
//
// <-- Short Description -->
// Blocks must have valid dimensions for their settings.
// Some dimensions were not coherents between theirs "set" and "define" method.
loadXcosLibs();

blocks = [ // Sources
           "CONST_m"
           "STEP_FUNCTION"
           "RAMP"
           "CURV_f"
           "PULSE_SC"
           "GENSIN_f"
           "DIRAC"
           "TRAPEZOID"
           "READ_CSV"
           // Operateurs lineaires
           "INTEGRAL_m"
           "PID"
           "BIGSOM_f"
           "GAINBLK_f"
           "CLR"
           "PIcontrol"
           // Non-linearites
           "TIME_DELAY"
           "SATURATION"
           "HYSTHERESIS"
           "DEADBAND"
           "scifunc_block_m"
           "RELAY"
           "PLAGE_LINEAIRE_INT"
           "PLAGE_LINEAIRE_EXT"
           "SEUIL"
           // Sorties
           "SCOPE"
           "WRITE_CSV"
           "MUX"
           "CSCOPE"
           "CMSCOPE"
           "CLOCK_c"
           "ENDBLK"
           "SELF_SWITCH"
           // Analyses
           "REP_TEMP"
           "REP_FREQ"
           "GRANDEUR_PHYSIQUE"
           "PARAM_VAR"
           // Fonctionnalites Avancees
           "MAXPID"
           "IMPRIMANTE"
         ];

notTested = ["PARAM_VAR"];

funcprot(0);

for j = 1:size(blocks,"*")
    interfunction = blocks(j);

// Not tested blocks
    if or(interfunction == notTested) then
        continue;
    end

    needcompile = 0;
    alreadyran = %f;
    %scicos_context = struct();

    [status, message] = xcosValidateBlockSet(blocks(j));
    if status == %f
        disp("Error on block "+blocks(j));
        disp(message);
    end
    assert_checktrue(status);
end
