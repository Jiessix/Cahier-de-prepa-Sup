// ============================================================================
// Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
// Copyright (C) 2013 - Scilab Enterprises - Bruno JOFRET
//
//  This file is distributed under the same license as the Scilab package.
// ============================================================================
//
// <-- ENGLISH IMPOSED -->
//
// <-- Short Description -->
// Test MCC_developpe_param
[a, cpgeMacrosPath] = libraryinfo(whereis(getCPGEVersion));

assert_checktrue(importXcosDiagram(cpgeMacrosPath + "/../examples/MCC_developpe_param.xcos"));

xcos_simulate(scs_m, 4);

// Une fenetre doit s'ouvrir
assert_checktrue(~isempty(winsid()));

f = gcf();
a = gca();

assert_checkequal(size(a.children, '*'), 4); // Legend, Compound, Compound, Compound
e1 = a.children(1);

// Teste que la legende contient bien le bon texte
assert_checkequal(e1.type, "Legend");
assert_checkequal(e1.text, ["Jeq=0.00004 Vitesse (rad/s)";"Jeq=0.00005 Vitesse (rad/s)";"Jeq=0.00006 Vitesse (rad/s)"]);

// Recuperation des donnees
data1 = e1.links(1).data;
data2 = e1.links(2).data;
data3 = e1.links(3).data;

// Toutes les courbes ont le meme pas de temps
assert_checkequal(data1(:,1), data2(:,1));
assert_checkequal(data2(:,1), data3(:,1));
assert_checkequal(data1(:,1), data3(:,1));

// Toutes les courbes doivent avoir des valeurs differentes
assert_checkfalse(and(data1(:,2) == data2(:,2)));
assert_checkfalse(and(data2(:,2) == data3(:,2)));
assert_checkfalse(and(data1(:,2) == data3(:,2)));
